/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package Project;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author haran
 */
public class CustomerController extends loginController implements Initializable {
    Bank bank = new Bank();
    
    @FXML
    private TextField enteredAmount; 

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    //if the balance button is clicked an alert containing the current balance and status will pop up
    @FXML
    private void btnBalanceClicked(ActionEvent event)
    {   
        Alert loginAlert = new Alert(Alert.AlertType.INFORMATION);
        loginAlert.setHeaderText("User info");
        loginAlert.setContentText("Balance: " + currUser.getBalance() + "\n" + "Status: " + currUser.getStatus());
        loginAlert.showAndWait();
    }
    
    //code block for when the deposit button is clicked
    @FXML
    private void btnDepositClicked(ActionEvent event) throws IOException {
        //checks if the text field is empty and if it is an error will pop up
        if(enteredAmount.getText().isEmpty())
        {
            Alert errorAlert = new Alert(Alert.AlertType.ERROR);
            errorAlert.setHeaderText("Input not valid");
            errorAlert.setContentText("A value must be entered");
            errorAlert.showAndWait();
        }
        else
        {
            //try catch used to check if entered amount value is valid
            try
            {
                //finds the double value of the amount entered
                double amount = Double.valueOf(enteredAmount.getText());

                //checks if the amount is zero or less and if it is an error will pop up
                if (amount <= 0)
                {
                    Alert errorAlert = new Alert(Alert.AlertType.ERROR);
                    errorAlert.setHeaderText("Input not valid");
                    errorAlert.setContentText("Amount must be greater than zero");
                    errorAlert.showAndWait();
                }
                else
                {
                    //an alert pops up to show the transaction was sucessful
                    Alert loginAlert = new Alert(Alert.AlertType.INFORMATION);
                    loginAlert.setHeaderText("Success");
                    loginAlert.setContentText("Transaction success");
                    loginAlert.showAndWait();

                    //adds to the balance, checks the users status, and updates the file
                    currUser.setBalance(currUser.getBalance() + amount);
                    currUser.checkStatus();
                    currUser.updateFile();
                } 
            }
            catch(RuntimeException e)
            {
                //if invalid entry an error alert will pop up
                Alert errorAlert = new Alert(Alert.AlertType.ERROR);
                errorAlert.setHeaderText("Input not valid");
                errorAlert.setContentText("Invalid amount entry");
                errorAlert.showAndWait();
            }           
        }
    }

    //code block for when withdraw is clicked
    @FXML
    private void btnWithdrawClicked(ActionEvent event) throws IOException {
        //checks if the text field is empty and if it is an error will pop up
        if(enteredAmount.getText().isEmpty())
        {
            Alert errorAlert = new Alert(Alert.AlertType.ERROR);
            errorAlert.setHeaderText("Input not valid");
            errorAlert.setContentText("A value must be entered");
            errorAlert.showAndWait();
        }
        else
        {
            //try catch used to check if entered amount value is valid
            try
            {
                 //finds the double value of the amount entered
                double amount = Double.valueOf(enteredAmount.getText());

                //checks if the amount is zero or less and if it is an error will pop up
                if (amount <= 0)
                {
                    Alert errorAlert = new Alert(Alert.AlertType.ERROR);
                    errorAlert.setHeaderText("Input not valid");
                    errorAlert.setContentText("Amount must be greater than zero");
                    errorAlert.showAndWait();
                }
                //checks if the amount is greater than the balance and if it is an error will pop up
                else if (currUser.getBalance() < amount)
                {
                    Alert errorAlert = new Alert(Alert.AlertType.ERROR);
                    errorAlert.setHeaderText("Account error");
                    errorAlert.setContentText("Insufficient funds");
                    errorAlert.showAndWait();
                }
                else
                {
                    //an alert pops up to show the transaction was sucessful
                    Alert loginAlert = new Alert(Alert.AlertType.INFORMATION);
                    loginAlert.setHeaderText("Success");
                    loginAlert.setContentText("Transaction success");
                    loginAlert.showAndWait();

                    //deducts from the balance, checks the users status, and updates the file
                    currUser.setBalance(currUser.getBalance() - amount);
                    currUser.checkStatus();
                    currUser.updateFile();
                }
            }
            catch(RuntimeException e)
            {
                //if invalid entry an error alert will pop up
                Alert errorAlert = new Alert(Alert.AlertType.ERROR);
                errorAlert.setHeaderText("Input not valid");
                errorAlert.setContentText("Invalid amount entry");
                errorAlert.showAndWait();
            }  
        } 
    }

    //code block for when the online purchase button is clicked
    @FXML
    private void btnOnlineClicked(ActionEvent event) throws IOException {
        if(enteredAmount.getText().isEmpty())
        {
            Alert errorAlert = new Alert(Alert.AlertType.ERROR);
            errorAlert.setHeaderText("Input not valid");
            errorAlert.setContentText("A value must be entered");
            errorAlert.showAndWait();
        }
        else
        {
            try
            {
                double amount = Double.valueOf(enteredAmount.getText());

                //checks if the amount is below 50 and if it is an error will pop up
                if (amount < 50)
                {
                    Alert errorAlert = new Alert(Alert.AlertType.ERROR);
                    errorAlert.setHeaderText("Input not valid");
                    errorAlert.setContentText("Amount must be greater than 50");
                    errorAlert.showAndWait();
                }
                //checks if the amount including the adjustment is greater than the balance and if it is an error will pop up
                else if (currUser.getBalance() < amount + currUser.getAdjustment())
                {
                    Alert errorAlert = new Alert(Alert.AlertType.ERROR);
                    errorAlert.setHeaderText("Account error");
                    errorAlert.setContentText("Insufficient funds");
                    errorAlert.showAndWait();
                }
                else
                {
                Alert loginAlert = new Alert(Alert.AlertType.INFORMATION);
                loginAlert.setHeaderText("Success");
                loginAlert.setContentText("Transaction success");
                loginAlert.showAndWait();

                //deducts from the balance, checks the users status, and updates the file
                currUser.setBalance(currUser.getBalance() - amount - currUser.getAdjustment());
                currUser.checkStatus();
                currUser.updateFile();
                }
            }
            catch(RuntimeException e)
            {
                //if invalid entry an error alert will pop up
                Alert errorAlert = new Alert(Alert.AlertType.ERROR);
                errorAlert.setHeaderText("Input not valid");
                errorAlert.setContentText("Invalid amount entry");
                errorAlert.showAndWait();
            }
        }
    }

    //if the customer selects back it goes back to the login scene
    @FXML
    private void btnBackClicked(ActionEvent event) throws IOException {
        bank.change("login.fxml");
    }
    
}
