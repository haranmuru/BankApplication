/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package Project;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.Scanner;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author haran
 */
public class ManagerController implements Initializable {
    Bank bank = new Bank();

    @FXML
    private PasswordField password;
    @FXML
    private TextField username;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    //code for when the manager clicks create
    @FXML
    private void btnCreateClicked(ActionEvent event) throws IOException {
        //checks if the fields are empty and if they are an error alert will pop up
        if(username.getText().isEmpty() || password.getText().isEmpty())
        {
            Alert errorAlert = new Alert(AlertType.ERROR);
            errorAlert.setHeaderText("Input not valid");
            errorAlert.setContentText("Username and/or password was not entered");
            errorAlert.showAndWait();
        }
        else
        {
            //creates a file object used to check if a file with the username exisits
            File check = new File("./Users/" + username.getText() + ".txt");
            
            //conditional that runs when the file does not exist
            if(!check.exists())
            {
                //creates a file and writes the information and starting balance to it
                FileWriter a = new FileWriter("./Users/" + username.getText() + ".txt");
                String start = username.getText() + "\n" + password.getText() + "\n" + 100.00;
                a.write(start);
                a.close();
                
                //an alert pops up to show success
                Alert createAlert = new Alert(Alert.AlertType.INFORMATION);
                createAlert.setHeaderText("Success");
                createAlert.setContentText("User created");
                createAlert.showAndWait();
            }
            else
            {
                //if the file exists an error alert will pop up
                Alert errorAlert = new Alert(AlertType.ERROR);
                errorAlert.setHeaderText("Input not valid");
                errorAlert.setContentText("Account with username already exists");
                errorAlert.showAndWait();
            }
        }
    }

    //code for when the manager clicks delete
    @FXML
    private void btnDeleteClicked(ActionEvent event) throws IOException {
        //checks if the fields are empty and if they are an error alert will pop up
        if(username.getText().isEmpty() || password.getText().isEmpty())
        {
            Alert errorAlert = new Alert(AlertType.ERROR);
            errorAlert.setHeaderText("Input not valid");
            errorAlert.setContentText("Username and/or password was not entered");
            errorAlert.showAndWait();
        }
        else
        {  
            //creates a file object used to check if a file with the username exisits
            File check = new File("./Users/" + username.getText() + ".txt");
            
            //conditional that runs if the file exists
            if(check.exists())
            {
                //uses a scanner to pull the data from the file
                Scanner myReader = new Scanner(check);
                String user = myReader.nextLine();
                String pass = myReader.nextLine();
                myReader.close();
                
                //checks if the password matches
                if(password.getText().equals(pass))
                {             
                    //uses a conditional to delete the file
                    if(check.delete())
                    {
                        //alert pops up to show delete was successful
                        Alert deleteAlert = new Alert(AlertType.INFORMATION);
                        deleteAlert.setHeaderText("Success");
                        deleteAlert.setContentText("User deleted");
                        deleteAlert.showAndWait();
                    }
                    else
                    {
                        //alert to show delete failed
                        Alert deleteAlert = new Alert(AlertType.ERROR);
                        deleteAlert.setHeaderText("Error");
                        deleteAlert.setContentText("Was not able to delete");
                        deleteAlert.showAndWait();
                    }
                }
                else
                {
                    //if the password does not match an error alert will pop up
                    Alert errorAlert = new Alert(AlertType.ERROR);
                    errorAlert.setHeaderText("Input not valid");
                    errorAlert.setContentText("Password does not match user");
                    errorAlert.showAndWait();
                }
            }
            else
            {
                //if the file does not exists an error alert will pop up
                Alert errorAlert = new Alert(AlertType.ERROR);
                errorAlert.setHeaderText("Input not valid");
                errorAlert.setContentText("Account with username does not exist");
                errorAlert.showAndWait();
            }
        }
    }
    
    //code for when the manager clicks back
    @FXML 
    private void btnBackClicked(ActionEvent event) throws IOException
    {
        //goes back to the login scene
        bank.change("login.fxml");
    }
    
}
