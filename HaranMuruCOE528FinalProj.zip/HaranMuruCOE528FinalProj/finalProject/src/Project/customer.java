/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Project;

import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;

/**
 *
 * @author haran
 */

// Overview: customer is mutable that contains bounded parameters.
//
// The abstraction function is:
// a) Write the abstraction function here
//      AF(c) = {c.status = "Silver" & c.adjustment = 20 | 0 <= c.balance < 10000}
//      AF(c) = {c.status = "Gold" & c.adjustment = 10 | 10000 <= c.balance < 20000}
//      AF(c) = {c.status = "Platinum" & c.adjustment = 0 | c.balance >= 20000}
//      this.username = username, this.password = password, this.status = status, this.balance = balance, this.adjustment = adjustment
//
// The rep invariant is:
// b) Write the rep invariant here
//      username, password, and status are non-empty strings. 
//      balance, and adjustment are double that are greater than or equal to zero.    
//
//

public class customer {
    
    //declares instance variables
    private String username, password, status;
    private double balance, adjustment;
    private static final DecimalFormat df = new DecimalFormat("0.00");
    
    //creates a customer object with the respective parameters

    /**
     *
     * @param username
     * @param password
     * @param balance
     */
    public customer(String username, String password, double balance)
    {
        this.username = username;
        this.password = password;
        this.balance = balance;
        
        this.checkStatus();
        
    }

    //geters and setters for the instance variables

    /**
     *
     * @return
     */
    public String getUsername() {
        // MODIFIES: n/a
        // EFFECTS: returns the username string
        // REQUIRES: the username string
        
        return username;
    }

    /**
     *
     * @param username
     */
    public void setUsername(String username) {
        // MODIFIES: changes the username string to a new value
        // EFFECTS: n/a
        // REQUIRES: the username string and a new value
        
        this.username = username;
    }

    /**
     *
     * @return
     */
    public String getPassword() {
        // MODIFIES: n/a
        // EFFECTS: returns the password string
        // REQUIRES: the password string
        
        return password;
    }

    /**
     *
     * @param password
     */
    public void setPassword(String password) {
        // MODIFIES: changes the password string to a new value
        // EFFECTS: n/a
        // REQUIRES: the password string and a new value
        
        this.password = password;
    }
    
    /**
     *
     * @return
     */
    public double getAdjustment() {
        // MODIFIES: n/a
        // EFFECTS: returns the adjustment double
        // REQUIRES: the adjustment double
        
        return adjustment;
    }

    /**
     *
     * @param adjustment
     */
    public void setAdjustment(double adjustment) {
        // MODIFIES: changes the adjustment double to a new value
        // EFFECTS: n/a
        // REQUIRES: the adjustment double and a new value
                
        this.adjustment = adjustment;
    }

    /**
     *
     * @return
     */
    public String getStatus() {
        // MODIFIES: n/a
        // EFFECTS: returns the status string
        // REQUIRES: the status string
        
        return status;
    }

    /**
     *
     * @param status
     */
    public void setStatus(String status) {
        // MODIFIES: changes the status string to a new value
        // EFFECTS: n/a
        // REQUIRES: the status string and a new value
                
        this.status = status;
    }

    /**
     *
     * @return
     */
    public double getBalance() {
        // MODIFIES: n/a
        // EFFECTS: returns the balance double
        // REQUIRES: the balance double
        
        return balance;
    }

    /**
     *
     * @param balance
     */
    public void setBalance(double balance) {
        // MODIFIES: changes the balance double to a new value
        // EFFECTS: n/a
        // REQUIRES: the balance double and a new value
        
        this.balance = balance;
    }
    
    //method to change the user's status and their online purchase adjustment based on their current balance

    /**
     *
     */
    public void checkStatus()
    {
        // MODIFIES: changes the customers status and adjustment based on their current balance
        // EFFECTS: n/a
        // REQUIRES: the current balance
        
        if (balance >= 20000)
        {
            this.status = "Platinum";
            this.adjustment = 0;
        }
        else if (balance >= 10000)
        {
            this.status = "Gold";
            this.adjustment = 10;
        }
        else
        {
            this.status = "Silver";
            this.adjustment = 20;
        }
    }
    
    //method that updates the user's file with their up to date data

    /**
     *
     * @throws IOException
     */
    public void updateFile() throws IOException
    {
        // MODIFIES: updates any changed customer data values
        // EFFECTS: n/a
        // REQUIRES: the username, password, and balance
        
        String roundedBal = df.format(this.getBalance());
        this.setBalance( Double.valueOf(roundedBal));
        
        FileWriter a = new FileWriter("./Users/" + this.getUsername() + ".txt");
        String start = this.getUsername() + "\n" + this.getPassword() + "\n" + this.getBalance();
        a.write(start);
        a.close();      
    }
    
    /**
     *
     * @return
     */
    public boolean repOK() {
        // EFFECTS: Returns true if the rep invariant holds for this
        // object; otherwise returns false
        
        return !(this.getBalance() < 0 || this.getAdjustment() < 0 || this.getUsername().isEmpty() || this.getPassword().isEmpty() || this.getStatus().isEmpty());
    }
    
    /**
     *
     * @return
     */
    @Override
    public String toString() {
        // EFFECTS: Returns a string that contains the strings in the
        // stack and the top element. Implements the abstraction function.
    
        return this.getUsername() + this.getPassword() +this.getStatus() + this.getBalance() + this.getAdjustment();
    }
}
