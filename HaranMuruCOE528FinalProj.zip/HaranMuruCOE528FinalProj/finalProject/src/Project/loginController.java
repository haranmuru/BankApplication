/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package Project;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.Scanner;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author haran
 */
public class loginController implements Initializable {

    //initalizes the variables for the password and username fields
    @FXML
    private PasswordField password;
    @FXML
    private TextField username;
    
    //declares a variable user to hold a customer
    protected static customer currUser;
    
    /**
         * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    //code block for the login button is clicked
    @FXML
    private void btnLoginClicked(ActionEvent event) throws IOException {
        Bank bank = new Bank();
        
        //conditional to check if the username or password fields are empty
        if(username.getText().isEmpty() || password.getText().isEmpty())
        {
            //an error alert will pop up if the conditionals passes
            Alert errorAlert = new Alert(Alert.AlertType.ERROR);
            errorAlert.setHeaderText("Input not valid");
            errorAlert.setContentText("Username and/or password was not entered");
            errorAlert.showAndWait();
        }
        //conditional to check if the manager is logging in
        else if (username.getText().equals("admin") && password.getText().equals("admin"))
        {
            //changes to the manager scene
            bank.change("manager.fxml");
            
            //an alert pops up to show login was successful
            Alert loginAlert = new Alert(Alert.AlertType.INFORMATION);
            loginAlert.setHeaderText("Success");
            loginAlert.setContentText("Login success");
            loginAlert.showAndWait();
        }
        else
        {
            //sets the object to a file with the same name as the user
            File check = new File("./Users/" + username.getText() + ".txt");
            
            //conditional if the file exists
            if(check.exists())
            {          
                //uses a scanner to pull the information from the text file
                Scanner myReader = new Scanner(check);
                String user = myReader.nextLine();
                String pass = myReader.nextLine();
                double balance = myReader.nextDouble();
                myReader.close();
                
                //checks if the inputed password matches the password in the file
                if(password.getText().equals(pass))
                {   
                    //if the login was sucessful the customer object is set with the relavant data
                    currUser = new customer(user, pass, balance);
                    
                    //changes to the customer scene
                    bank.change("customer.fxml");
                    
                    //an alert pops up to show the login was sucessful
                    Alert loginAlert = new Alert(Alert.AlertType.INFORMATION);
                    loginAlert.setHeaderText("Success");
                    loginAlert.setContentText("Login success");
                    loginAlert.showAndWait();
                }
                else
                {
                    //if the password does not match an error alert will pop up
                    Alert errorAlert = new Alert(Alert.AlertType.ERROR);
                    errorAlert.setHeaderText("Input not valid");
                    errorAlert.setContentText("Password does not match user");
                    errorAlert.showAndWait();
                }
            }
            else
            {
                //if the file does not exists an error alert will pop up
                Alert errorAlert = new Alert(Alert.AlertType.ERROR);
                errorAlert.setHeaderText("Input not valid");
                errorAlert.setContentText("Account with username does not exists");
                errorAlert.showAndWait();
            }      
        }
    }  
}
