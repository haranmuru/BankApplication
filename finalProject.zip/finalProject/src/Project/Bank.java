/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMain.java to edit this template
 */
package Project;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.image.Image;

/**
 *
 * @author haran
 */
public class Bank extends Application {
    //declares a variable for the stage
    private static Stage stage;
    
    @Override 
    public void start(Stage primaryStage) throws IOException {
        stage = primaryStage;

        //loads the login scene as the inital stage for when the program runs
        Parent root = FXMLLoader.load(getClass().getResource("login.fxml"));
            
        Scene scene = new Scene(root);
            
        //adds the components to the stage such as title, icon, scene, and then displays the stage
        primaryStage.setTitle("Bank");
        primaryStage.getIcons().add(new Image("https://static.vecteezy.com/system/resources/previews/021/375/941/original/bank-icon-for-your-website-design-logo-app-ui-free-vector.jpg"));
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    
    //method to change to another scene
    public void change(String next) throws IOException 
    {
        //loads the inputed scene to the stage
        Parent pane = FXMLLoader.load(getClass().getResource(next));
        
        stage.getScene().setRoot(pane);
    }
    
    public static void main(String[] args) {
        launch(args);
    }
    
}
